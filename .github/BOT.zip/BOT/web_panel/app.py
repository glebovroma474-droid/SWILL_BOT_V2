import os
import glob
import warnings
warnings.filterwarnings("ignore")

from datetime import datetime
from flask import Flask, render_template, redirect, url_for, jsonify, send_from_directory
from flask_login import LoginManager, login_required
from werkzeug.security import generate_password_hash
from waitress import serve
import config
import storage
import auth
from updater import start_updater
from auth import load_user, login, register, logout
from api_system import api_status, api_screenshot, get_local_ip
from api_control import api_do
from api_chat import api_chat_get, api_chat_send
from api_users import api_users_get, api_users_add, api_users_delete, api_settings_get, api_settings_save

app = Flask(__name__)
app.secret_key = config.SECRET_KEY

SCREENSHOTS_DIR = os.path.join(config.BASE_DIR, 'screenshots')
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login_route'
login_manager.user_loader(load_user)

@app.route('/')
@login_required
def index():
    return render_template('dashboard.html', user=auth.current_user.id, role=auth.current_user.role)

@app.route('/login', methods=['GET', 'POST'])
def login_route():
    return login()

@app.route('/register', methods=['GET', 'POST'])
def register_route():
    return register()

@app.route('/logout')
@login_required
def logout_route():
    return logout()

@app.route('/chat')
@login_required
def chat_page():
    return render_template('chat.html', user=auth.current_user.id)

@app.route('/admin')
@login_required
def admin_page():
    if auth.current_user.role != 'admin':
        return redirect(url_for('index'))
    return render_template('admin.html', user=auth.current_user.id)

@app.route('/customize')
@login_required
def customize_page():
    return render_template('customize.html', user=auth.current_user.id)

@app.route('/gallery')
@login_required
def gallery_page():
    return render_template('gallery.html', user=auth.current_user.id)

@app.route('/logs')
@login_required
def logs_page():
    return render_template('logs.html', user=auth.current_user.id)

@app.route('/api/status')
@login_required
def route_api_status():
    return api_status()

@app.route('/api/screenshot')
@login_required
def route_api_screenshot():
    return api_screenshot()

@app.route('/api/gallery')
@login_required
def route_api_gallery():
    files = []
    for f in sorted(glob.glob(os.path.join(SCREENSHOTS_DIR, '*.jpg')), reverse=True):
        name = os.path.basename(f)
        url = f'/screenshots/{name}'
        t = os.path.getmtime(f)
        time_str = datetime.fromtimestamp(t).strftime('%H:%M:%S')
        files.append({'name': name, 'url': url, 'time': time_str})
    return jsonify({'files': files})

@app.route('/screenshots/<path:filename>')
@login_required
def serve_screenshot(filename):
    return send_from_directory(SCREENSHOTS_DIR, filename)

@app.route('/api/logs')
@login_required
def route_api_logs():
    log = storage.load_json(config.LOG_FILE)
    return jsonify(log)

@app.route('/api/logs/clear', methods=['POST'])
@login_required
def route_api_logs_clear():
    storage.save_json(config.LOG_FILE, {})
    return jsonify({'ok': True})

@app.route('/api/do/<action>')
@login_required
def route_api_do(action):
    return api_do(action)

@app.route('/api/chat', methods=['GET'])
@login_required
def route_api_chat_get():
    return api_chat_get()

@app.route('/api/chat', methods=['POST'])
@login_required
def route_api_chat_send():
    return api_chat_send()

@app.route('/api/users', methods=['GET'])
@login_required
def route_api_users_get():
    return api_users_get()

@app.route('/api/users', methods=['POST'])
@login_required
def route_api_users_add():
    return api_users_add()

@app.route('/api/users/<username>', methods=['DELETE'])
@login_required
def route_api_users_delete(username):
    return api_users_delete(username)

@app.route('/api/settings', methods=['GET'])
@login_required
def route_api_settings_get():
    return api_settings_get()

@app.route('/api/settings', methods=['POST'])
@login_required
def route_api_settings_save():
    return api_settings_save()

if __name__ == '__main__':
    if not os.path.exists(config.USERS_FILE):
        users = {
            'admin': {
                'password': generate_password_hash('swill2025'),
                'role': 'admin',
                'color': '#4ade80',
                'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'last_login': '',
                'last_active': '',
                'xp': 0
            }
        }
        storage.save_json(config.USERS_FILE, users)

    ip = get_local_ip()
    print(f"\n{'='*50}\n  SWILL BOT V2\n  http://{ip}:{config.PORT}\n{'='*50}\n")
    start_updater(config.BASE_DIR)
    serve(app, host=config.HOST, port=config.PORT, threads=config.THREADS)