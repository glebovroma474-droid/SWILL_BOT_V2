from datetime import datetime
from flask import jsonify, request
from flask_login import current_user
from werkzeug.security import generate_password_hash
import config
import storage

def api_users_get():
    if current_user.role != 'admin':
        return jsonify({'error': 'Denied'}), 403
    users = storage.load_json(config.USERS_FILE)
    return jsonify({u: {k: v for k, v in users[u].items() if k != 'password'} for u in users})

def api_users_add():
    if current_user.role != 'admin':
        return jsonify({'error': 'Denied'}), 403
    d = request.json
    u = d.get('username', '').strip()
    p = d.get('password', '').strip()
    if not u or not p:
        return jsonify({'error': 'Fill all fields'})
    users = storage.load_json(config.USERS_FILE)
    if u in users:
        return jsonify({'error': 'Exists'})
    users[u] = {
        'password': generate_password_hash(p),
        'role': d.get('role', 'user'),
        'color': '#4ade80',
        'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'last_login': '',
        'last_active': '',
        'xp': 0
    }
    storage.save_json(config.USERS_FILE, users)
    return jsonify({'ok': True})

def api_users_delete(username):
    if current_user.role != 'admin':
        return jsonify({'error': 'Denied'}), 403
    if username == 'admin':
        return jsonify({'error': 'Cannot delete admin'})
    users = storage.load_json(config.USERS_FILE)
    if username in users:
        del users[username]
        storage.save_json(config.USERS_FILE, users)
        return jsonify({'ok': True})
    return jsonify({'error': 'Not found'}), 404

def api_settings_get():
    return jsonify(storage.load_json(config.SETTINGS_FILE).get(current_user.id, {}))

def api_settings_save():
    s = storage.load_json(config.SETTINGS_FILE)
    s[current_user.id] = request.json
    storage.save_json(config.SETTINGS_FILE, s)
    return jsonify({'ok': True})