import time
import os as _os
import socket
import subprocess
import ctypes
from datetime import datetime, timedelta
import psutil
import pyautogui
from flask import jsonify
from flask_login import current_user
import config
import storage
from services_audio import audio
from services_input import input_blocker

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return 'N/A'

def get_brightness():
    try:
        import warnings
        warnings.filterwarnings("ignore")
        import screen_brightness_control as sbc
        b = sbc.get_brightness()
        if isinstance(b, list):
            return b[0]
        return b
    except:
        return 50

def get_sys_info():
    cpu = psutil.cpu_percent(interval=0)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage('C:')
    
    cpu_temp = "N/A"
    try:
        temps = psutil.sensors_temperatures()
        if 'coretemp' in temps:
            cpu_temp = f"{temps['coretemp'][0].current}°C"
    except:
        pass
    
    battery = 'N/A'
    try:
        b = psutil.sensors_battery()
        if b:
            battery = f"{int(b.percent)}% {'AC' if b.power_plugged else 'BAT'}"
    except:
        pass
    
    try:
        net1 = psutil.net_io_counters()
        time.sleep(0.3)
        net2 = psutil.net_io_counters()
        dl = (net2.bytes_recv - net1.bytes_recv) / 1024 * 3
        ul = (net2.bytes_sent - net1.bytes_sent) / 1024 * 3
        dl = f"{dl/1024:.1f} MB/s" if dl > 1024 else f"{dl:.0f} KB/s"
        ul = f"{ul/1024:.1f} MB/s" if ul > 1024 else f"{ul:.0f} KB/s"
    except:
        dl = ul = "N/A"
    
    try:
        sec = ctypes.windll.kernel32.GetTickCount64() / 1000
        uptime = str(timedelta(seconds=int(sec)))
    except:
        uptime = "N/A"
    
    try:
        import win32gui
        hwnd = win32gui.GetForegroundWindow()
        active = win32gui.GetWindowText(hwnd) or "Desktop"
    except:
        active = "Unknown"
    
    try:
        r = subprocess.run(['ping', '-n', '1', 'google.com'], capture_output=True, text=True, timeout=2)
        ping = r.stdout.split('time=')[1].split('ms')[0].strip() + ' ms' if 'time=' in r.stdout else 'N/A'
    except:
        ping = 'N/A'
    
    return {
        'cpu': cpu,
        'ram_percent': ram.percent,
        'ram_used': f"{ram.used/(1024**3):.1f}",
        'ram_total': f"{ram.total/(1024**3):.1f}",
        'disk_percent': disk.percent,
        'temp': cpu_temp,
        'battery': battery,
        'uptime': uptime,
        'hostname': socket.gethostname(),
        'local_ip': get_local_ip(),
        'active_window': active,
        'locked': input_blocker.is_locked,
        'volume': audio.get(),
        'brightness': get_brightness(),
        'network': {'download': dl, 'upload': ul},
        'ping': ping,
        'time': datetime.now().strftime('%H:%M:%S')
    }

def api_status():
    return jsonify(get_sys_info())

def api_screenshot():
    try:
        shot = pyautogui.screenshot()
        filename = f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        filepath = _os.path.join(config.BASE_DIR, 'screenshots', filename)
        _os.makedirs(_os.path.dirname(filepath), exist_ok=True)
        shot.save(filepath, format='JPEG', quality=70)
        return jsonify({'ok': True, 'msg': 'Сохранено'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})