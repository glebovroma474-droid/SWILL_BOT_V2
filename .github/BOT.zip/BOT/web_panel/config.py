import os
import secrets

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SECRET_KEY = secrets.token_hex(32)

USERS_FILE = os.path.join(BASE_DIR, 'users.json')
SETTINGS_FILE = os.path.join(BASE_DIR, 'user_settings.json')
LOG_FILE = os.path.join(BASE_DIR, 'swill_log.json')
CHAT_FILE = os.path.join(BASE_DIR, 'chat.json')
BLOCKED_FILE = os.path.join(BASE_DIR, 'blocked.json')

MAX_LOGIN_ATTEMPTS = 5
BLOCK_DURATION_MINUTES = 30

HOST = '0.0.0.0'
PORT = 8080
THREADS = 4