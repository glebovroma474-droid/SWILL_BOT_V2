import sys
import os
import ctypes
import math
import psutil
from datetime import datetime
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QSlider, QProgressBar, QGraphicsOpacityEffect,
    QFrame, QGridLayout
)
from PyQt6.QtCore import Qt, QTimer, QPropertyAnimation, QEasingCurve
from PyQt6.QtGui import QFont, QColor, QPainter, QPen, QBrush, QLinearGradient

class SplashScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(400, 300)
        
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        
        self.logo = QLabel("SWILL")
        self.logo.setFont(QFont("Segoe UI", 48, QFont.Weight.Bold))
        self.logo.setStyleSheet("color: #ffffff;")
        self.logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.logo)
        
        self.sub = QLabel("BOT V2")
        self.sub.setFont(QFont("Segoe UI", 14))
        self.sub.setStyleSheet("color: #888888;")
        self.sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.sub)
        
        self.progress = QProgressBar()
        self.progress.setFixedSize(250, 4)
        self.progress.setStyleSheet("""
            QProgressBar { background: #1a1a1a; border: none; border-radius: 2px; }
            QProgressBar::chunk { background: #ffffff; border-radius: 2px; }
        """)
        self.progress.setTextVisible(False)
        layout.addWidget(self.progress, alignment=Qt.AlignmentFlag.AlignCenter)
        
        self.opacity_effect = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self.opacity_effect)
        
        self.fade_in = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_in.setDuration(1200)
        self.fade_in.setStartValue(0)
        self.fade_in.setEndValue(1)
        self.fade_in.start()
        
        self.progress_value = 0
        self.load_timer = QTimer()
        self.load_timer.timeout.connect(self.update_progress)
        self.load_timer.start(15)
        
        self.breath_phase = 0
        self.breath_timer = QTimer()
        self.breath_timer.timeout.connect(self.breathe)
        self.breath_timer.start(30)
    
    def update_progress(self):
        self.progress_value += 0.8
        if self.progress_value >= 100:
            self.progress.setValue(100)
            self.load_timer.stop()
            QTimer.singleShot(600, self.fade_out)
        else:
            self.progress.setValue(int(self.progress_value))
    
    def breathe(self):
        self.breath_phase += 0.03
        brightness = (math.sin(self.breath_phase) + 1) / 2
        v = int(180 + brightness * 75)
        self.logo.setStyleSheet(f"color: #{v:02x}{v:02x}{v:02x};")
    
    def fade_out(self):
        self.fade_out_anim = QPropertyAnimation(self.opacity_effect, b"opacity")
        self.fade_out_anim.setDuration(800)
        self.fade_out_anim.setStartValue(1)
        self.fade_out_anim.setEndValue(0)
        self.fade_out_anim.finished.connect(self.open_main)
        self.fade_out_anim.start()
    
    def open_main(self):
        self.main = SWILL_GUI()
        self.main.show()
        self.close()

class SWILL_GUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(430, 750)
        
        central = QWidget()
        central.setStyleSheet("background: transparent;")
        self.setCentralWidget(central)
        
        self.main_layout = QVBoxLayout(central)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(8)
        
        self.build_titlebar()
        self.build_status()
        self.build_monitor()
        self.build_buttons()
        self.build_sliders()
        
        self.drag_pos = None
        self.start_monitoring()
        self.sync_all()
    
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0, QColor(30, 30, 40, 240))
        gradient.setColorAt(0.5, QColor(20, 20, 28, 235))
        gradient.setColorAt(1, QColor(15, 15, 22, 240))
        painter.setBrush(QBrush(gradient))
        painter.setPen(QPen(QColor(255, 255, 255, 40), 1))
        painter.drawRoundedRect(0, 0, self.width(), self.height(), 28, 28)
    
    def build_titlebar(self):
        self.titlebar = QFrame()
        self.titlebar.setFixedHeight(45)
        self.titlebar.setStyleSheet("background: transparent;")
        layout = QHBoxLayout(self.titlebar)
        layout.setContentsMargins(20, 0, 10, 0)
        
        self.title_label = QLabel("⚡ SWILL")
        self.title_label.setFont(QFont("Segoe UI", 15, QFont.Weight.Bold))
        self.title_label.setStyleSheet("color: #ffffff;")
        layout.addWidget(self.title_label)
        layout.addStretch()
        
        self.btn_min = QPushButton("—")
        self.btn_min.setFixedSize(35, 35)
        self.btn_min.setStyleSheet("""
            QPushButton { background: rgba(255,255,255,15); color: #cccccc; border: none; border-radius: 10px; font-size: 16px; }
            QPushButton:hover { background: rgba(255,255,255,40); color: #ffffff; }
        """)
        self.btn_min.clicked.connect(self.showMinimized)
        self.btn_min.setToolTip("Свернуть")
        layout.addWidget(self.btn_min)
        
        self.btn_close = QPushButton("✕")
        self.btn_close.setFixedSize(35, 35)
        self.btn_close.setStyleSheet("""
            QPushButton { background: rgba(255,255,255,15); color: #cccccc; border: none; border-radius: 10px; font-size: 14px; }
            QPushButton:hover { background: #ff4444; color: #ffffff; }
        """)
        self.btn_close.clicked.connect(self.close)
        self.btn_close.setToolTip("Закрыть")
        layout.addWidget(self.btn_close)
        
        self.main_layout.addWidget(self.titlebar)
    
    def build_status(self):
        self.status_frame = QFrame()
        self.status_frame.setStyleSheet("""
            QFrame { background: rgba(255,255,255,15); border: 1px solid rgba(255,255,255,25); border-radius: 16px; }
        """)
        self.status_frame.setFixedHeight(50)
        layout = QHBoxLayout(self.status_frame)
        layout.setContentsMargins(15, 0, 15, 0)
        
        self.status_dot = QLabel("●")
        self.status_dot.setFont(QFont("Segoe UI", 14))
        self.status_dot.setStyleSheet("color: #00ff00;")
        layout.addWidget(self.status_dot)
        
        self.status_text = QLabel("Онлайн • --:--:--")
        self.status_text.setFont(QFont("Segoe UI", 12))
        self.status_text.setStyleSheet("color: #cccccc;")
        layout.addWidget(self.status_text)
        
        wrapper = QWidget()
        wrapper.setStyleSheet("background: transparent;")
        wl = QHBoxLayout(wrapper)
        wl.setContentsMargins(15, 0, 15, 0)
        wl.addWidget(self.status_frame)
        self.main_layout.addWidget(wrapper)
        
        self.dot_phase = 0
        self.dot_timer = QTimer()
        self.dot_timer.timeout.connect(self.breathe_dot)
        self.dot_timer.start(40)
    
    def breathe_dot(self):
        self.dot_phase += 0.05
        if (math.sin(self.dot_phase) + 1) / 2 > 0.5:
            self.status_dot.setStyleSheet("color: #00ff00;")
        else:
            self.status_dot.setStyleSheet("color: rgba(0,255,0,50);")
    
    def build_monitor(self):
        self.monitor_frame = QFrame()
        self.monitor_frame.setStyleSheet("""
            QFrame { background: rgba(255,255,255,15); border: 1px solid rgba(255,255,255,25); border-radius: 16px; }
        """)
        layout = QVBoxLayout(self.monitor_frame)
        layout.setContentsMargins(20, 10, 20, 10)
        
        self.cpu_label = QLabel("Процессор: 0%")
        self.cpu_label.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        self.cpu_label.setStyleSheet("color: #ffffff;")
        layout.addWidget(self.cpu_label)
        
        self.cpu_bar = QProgressBar()
        self.cpu_bar.setFixedHeight(8)
        self.cpu_bar.setStyleSheet("""
            QProgressBar { background: rgba(255,255,255,20); border: none; border-radius: 4px; }
            QProgressBar::chunk { background: #ffffff; border-radius: 4px; }
        """)
        self.cpu_bar.setTextVisible(False)
        layout.addWidget(self.cpu_bar)
        
        self.ram_label = QLabel("Память: 0%")
        self.ram_label.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        self.ram_label.setStyleSheet("color: #ffffff;")
        layout.addWidget(self.ram_label)
        
        self.ram_bar = QProgressBar()
        self.ram_bar.setFixedHeight(8)
        self.ram_bar.setStyleSheet("""
            QProgressBar { background: rgba(255,255,255,20); border: none; border-radius: 4px; }
            QProgressBar::chunk { background: #ffffff; border-radius: 4px; }
        """)
        self.ram_bar.setTextVisible(False)
        layout.addWidget(self.ram_bar)
        
        wrapper = QWidget()
        wrapper.setStyleSheet("background: transparent;")
        wl = QHBoxLayout(wrapper)
        wl.setContentsMargins(15, 0, 15, 0)
        wl.addWidget(self.monitor_frame)
        self.main_layout.addWidget(wrapper)
    
    def build_buttons(self):
        self.buttons_frame = QFrame()
        self.buttons_frame.setStyleSheet("""
            QFrame { background: rgba(255,255,255,15); border: 1px solid rgba(255,255,255,25); border-radius: 16px; }
        """)
        grid = QGridLayout(self.buttons_frame)
        grid.setContentsMargins(10, 10, 10, 10)
        grid.setSpacing(8)
        
        buttons = [
            ("🔒 Блок", "Заблокировать компьютер", self.btn_lock),
            ("😴 Сон", "Спящий режим", self.btn_sleep),
            ("📺 Экран", "Выключить экран", self.btn_screen_off),
            ("🔊+", "Громкость +", self.btn_vol_up),
            ("🔊-", "Громкость -", self.btn_vol_down),
            ("🔇", "Без звука", self.btn_mute),
            ("⚡ Ребут", "Перезагрузить", self.btn_reboot),
            ("⏻ Выкл", "Выключить ПК", self.btn_shutdown),
            ("🧹 Чистка", "Очистить темп", self.btn_clean),
        ]
        
        for i, (text, tip, cmd) in enumerate(buttons):
            row, col = divmod(i, 3)
            btn = QPushButton(text)
            btn.setFixedHeight(45)
            btn.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold))
            btn.setStyleSheet("""
                QPushButton { background: rgba(255,255,255,20); color: #ffffff; border: 1px solid rgba(255,255,255,30); border-radius: 14px; }
                QPushButton:hover { background: rgba(255,255,255,45); }
                QPushButton:pressed { background: rgba(255,255,255,70); }
            """)
            btn.setToolTip(tip)
            btn.clicked.connect(cmd)
            grid.addWidget(btn, row, col)
        
        wrapper = QWidget()
        wrapper.setStyleSheet("background: transparent;")
        wl = QHBoxLayout(wrapper)
        wl.setContentsMargins(15, 0, 15, 0)
        wl.addWidget(self.buttons_frame)
        self.main_layout.addWidget(wrapper)
    
    def build_sliders(self):
        self.sliders_frame = QFrame()
        self.sliders_frame.setStyleSheet("""
            QFrame { background: rgba(255,255,255,15); border: 1px solid rgba(255,255,255,25); border-radius: 16px; }
        """)
        layout = QVBoxLayout(self.sliders_frame)
        layout.setContentsMargins(20, 10, 20, 10)
        
        self.vol_label = QLabel("🔊 Громкость: --%")
        self.vol_label.setFont(QFont("Segoe UI", 12))
        self.vol_label.setStyleSheet("color: #ffffff;")
        layout.addWidget(self.vol_label)
        
        self.vol_slider = QSlider(Qt.Orientation.Horizontal)
        self.vol_slider.setRange(0, 100)
        self.vol_slider.setStyleSheet("""
            QSlider::groove:horizontal { height: 6px; background: rgba(255,255,255,30); border-radius: 3px; }
            QSlider::sub-page:horizontal { background: #ffffff; border-radius: 3px; }
            QSlider::handle:horizontal { background: #ffffff; width: 22px; height: 22px; margin: -8px 0; border-radius: 11px; }
        """)
        self.vol_slider.valueChanged.connect(self.on_volume)
        layout.addWidget(self.vol_slider)
        
        self.bright_label = QLabel("🔆 Яркость: --%")
        self.bright_label.setFont(QFont("Segoe UI", 12))
        self.bright_label.setStyleSheet("color: #ffffff;")
        layout.addWidget(self.bright_label)
        
        self.bright_slider = QSlider(Qt.Orientation.Horizontal)
        self.bright_slider.setRange(0, 100)
        self.bright_slider.setStyleSheet("""
            QSlider::groove:horizontal { height: 6px; background: rgba(255,255,255,30); border-radius: 3px; }
            QSlider::sub-page:horizontal { background: #ffffff; border-radius: 3px; }
            QSlider::handle:horizontal { background: #ffffff; width: 22px; height: 22px; margin: -8px 0; border-radius: 11px; }
        """)
        self.bright_slider.valueChanged.connect(self.on_brightness)
        layout.addWidget(self.bright_slider)
        
        wrapper = QWidget()
        wrapper.setStyleSheet("background: transparent;")
        wl = QHBoxLayout(wrapper)
        wl.setContentsMargins(15, 0, 15, 0)
        wl.addWidget(self.sliders_frame)
        self.main_layout.addWidget(wrapper)
    
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and event.position().y() < 45:
            self.drag_pos = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
    
    def mouseMoveEvent(self, event):
        if self.drag_pos and event.buttons() == Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self.drag_pos)
            event.accept()
    
    def mouseReleaseEvent(self, event):
        self.drag_pos = None
    
    def start_monitoring(self):
        self.monitor_timer = QTimer()
        self.monitor_timer.timeout.connect(self.update_monitor)
        self.monitor_timer.start(2000)
    
    def update_monitor(self):
        try:
            cpu = psutil.cpu_percent()
            ram = psutil.virtual_memory().percent
            self.cpu_label.setText(f"Процессор: {cpu}%")
            self.ram_label.setText(f"Память: {ram}%")
            self.cpu_bar.setValue(int(cpu))
            self.ram_bar.setValue(int(ram))
            self.status_text.setText(f"Онлайн • {datetime.now().strftime('%H:%M:%S')}")
        except:
            pass
    
    def sync_all(self):
        self.sync_volume()
        self.sync_brightness()
    
    def sync_volume(self):
        try:
            from pycaw.pycaw import AudioUtilities
            vol = AudioUtilities.GetSpeakers().EndpointVolume
            v = int(vol.GetMasterVolumeLevelScalar() * 100)
            self.vol_slider.setValue(v)
            self.vol_label.setText(f"🔊 Громкость: {v}%")
        except:
            pass
    
    def sync_brightness(self):
        try:
            import screen_brightness_control as sbc
            b = sbc.get_brightness()
            if isinstance(b, list): b = b[0]
            self.bright_slider.setValue(b)
            self.bright_label.setText(f"🔆 Яркость: {b}%")
        except:
            pass
    
    def on_volume(self, value):
        self.vol_label.setText(f"🔊 Громкость: {value}%")
        try:
            from pycaw.pycaw import AudioUtilities
            AudioUtilities.GetSpeakers().EndpointVolume.SetMasterVolumeLevelScalar(value / 100.0, None)
        except:
            pass
    
    def on_brightness(self, value):
        self.bright_label.setText(f"🔆 Яркость: {value}%")
        try:
            import screen_brightness_control as sbc
            sbc.set_brightness(value)
        except:
            pass
    
    def btn_lock(self): ctypes.windll.user32.LockWorkStation()
    def btn_sleep(self): os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
    def btn_screen_off(self):
        ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)
        ctypes.windll.user32.keybd_event(0x4C, 0, 0, 0)
        ctypes.windll.user32.keybd_event(0x4C, 0, 2, 0)
        ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)
    def btn_vol_up(self):
        ctypes.windll.user32.keybd_event(0xAF, 0, 0, 0)
        ctypes.windll.user32.keybd_event(0xAF, 0, 2, 0)
        self.sync_volume()
    def btn_vol_down(self):
        ctypes.windll.user32.keybd_event(0xAE, 0, 0, 0)
        ctypes.windll.user32.keybd_event(0xAE, 0, 2, 0)
        self.sync_volume()
    def btn_mute(self):
        ctypes.windll.user32.keybd_event(0xAD, 0, 0, 0)
        ctypes.windll.user32.keybd_event(0xAD, 0, 2, 0)
    def btn_reboot(self): os.system("shutdown /r /f /t 0")
    def btn_shutdown(self): os.system("shutdown /s /f /t 0")
    def btn_clean(self):
        import tempfile
        count = 0
        try:
            for f in os.listdir(tempfile.gettempdir()):
                try:
                    fp = os.path.join(tempfile.gettempdir(), f)
                    if os.path.isfile(fp):
                        os.remove(fp)
                        count += 1
                except: pass
        except: pass
        self.status_text.setText(f"Очищено {count} файлов")
        QTimer.singleShot(2000, lambda: self.status_text.setText(f"Онлайн • {datetime.now().strftime('%H:%M:%S')}"))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    splash = SplashScreen()
    splash.show()
    sys.exit(app.exec())