from threading import RLock
from pynput import mouse, keyboard

class InputBlocker:
    def __init__(self):
        self._lock = RLock()
        self._ml = None
        self._kl = None
        self._locked = False
    
    @property
    def is_locked(self):
        return self._locked
    
    def toggle(self):
        with self._lock:
            if not self._locked:
                self._ml = mouse.Listener(suppress=True)
                self._kl = keyboard.Listener(suppress=True)
                self._ml.start()
                self._kl.start()
                self._locked = True
                return True
            else:
                if self._ml:
                    self._ml.stop()
                    self._ml = None
                if self._kl:
                    self._kl.stop()
                    self._kl = None
                self._locked = False
                return False

input_blocker = InputBlocker()