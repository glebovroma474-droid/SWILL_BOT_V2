import hashlib
import io
import json
import logging
import os
from pathlib import PurePosixPath
import shutil
import sys
import tempfile
import threading
import time
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import zipfile


REPOSITORY = "glebovroma474-droid/jarvis"
BRANCH = "main"
UPDATE_URL = (
    "https://raw.githubusercontent.com/"
    f"{REPOSITORY}/{BRANCH}/.github/BOT.zip"
)
CHECK_INTERVAL_SECONDS = 900
MAX_PACKAGE_SIZE = 50 * 1024 * 1024
MAX_UNPACKED_SIZE = 100 * 1024 * 1024
PACKAGE_ROOT = PurePosixPath("BOT/web_panel")
STATE_FILE = ".swill_update_state.json"
LOGGER = logging.getLogger("swill.updater")


def _request(url, method="GET"):
    request = Request(
        url,
        method=method,
        headers={"User-Agent": "SWILL-Bot-Updater", "Accept": "application/octet-stream"},
    )
    return urlopen(request, timeout=20)


def _remote_version():
    try:
        with _request(UPDATE_URL, "HEAD") as response:
            return response.headers.get("ETag") or response.headers.get("Last-Modified")
    except HTTPError as error:
        if error.code == 404:
            LOGGER.info("Файл обновления ещё не опубликован в GitHub: %s", UPDATE_URL)
            return None
        raise


def _download_package():
    with _request(UPDATE_URL) as response:
        package = response.read(MAX_PACKAGE_SIZE + 1)
    if len(package) > MAX_PACKAGE_SIZE:
        raise ValueError("Архив обновления превышает допустимый размер")
    return package


def _target_path(member_name):
    member = PurePosixPath(member_name)
    if member.is_absolute() or ".." in member.parts or member.parts[:2] != PACKAGE_ROOT.parts:
        return None

    relative = member.relative_to(PACKAGE_ROOT)
    if not relative.parts or relative.name == "config.py":
        return None
    if len(relative.parts) == 1 and relative.suffix == ".py":
        return relative
    if relative.parts[0] in {"templates", "static"}:
        return relative
    return None


def _install_package(package, base_dir):
    with zipfile.ZipFile(io.BytesIO(package)) as archive:
        if archive.testzip() is not None:
            raise ValueError("Контрольная сумма файла в архиве не совпала")

        members = []
        unpacked_size = 0
        for info in archive.infolist():
            target = _target_path(info.filename)
            if target is None or info.is_dir():
                continue
            unpacked_size += info.file_size
            if unpacked_size > MAX_UNPACKED_SIZE:
                raise ValueError("Распакованный архив превышает допустимый размер")
            members.append((info, target))

        if not members:
            raise ValueError("В архиве не найдены файлы приложения для обновления")

        changed = []
        with tempfile.TemporaryDirectory(prefix=".swill-update-", dir=base_dir) as temporary:
            staging = os.path.join(temporary, "staging")
            backups = os.path.join(temporary, "backups")

            for info, relative in members:
                staged_path = os.path.join(staging, *relative.parts)
                os.makedirs(os.path.dirname(staged_path), exist_ok=True)
                with archive.open(info) as source, open(staged_path, "wb") as target_file:
                    shutil.copyfileobj(source, target_file)

                installed_path = os.path.join(base_dir, *relative.parts)
                if not os.path.isfile(installed_path):
                    changed.append((staged_path, installed_path, None))
                else:
                    with open(installed_path, "rb") as installed_file:
                        installed_contents = installed_file.read()
                    with open(staged_path, "rb") as staged_file:
                        staged_contents = staged_file.read()
                    if installed_contents != staged_contents:
                        backup_path = os.path.join(backups, *relative.parts)
                        changed.append((staged_path, installed_path, backup_path))

            if not changed:
                return False

            applied = []
            try:
                for staged_path, installed_path, backup_path in changed:
                    os.makedirs(os.path.dirname(installed_path), exist_ok=True)
                    if backup_path:
                        os.makedirs(os.path.dirname(backup_path), exist_ok=True)
                        shutil.copy2(installed_path, backup_path)
                    os.replace(staged_path, installed_path)
                    applied.append((installed_path, backup_path))
            except Exception:
                for installed_path, backup_path in reversed(applied):
                    if backup_path:
                        os.replace(backup_path, installed_path)
                    elif os.path.exists(installed_path):
                        os.remove(installed_path)
                raise

    return True


def _state_path(base_dir):
    return os.path.join(base_dir, STATE_FILE)


def _read_state(base_dir):
    try:
        with open(_state_path(base_dir), "r", encoding="utf-8") as state_file:
            state = json.load(state_file)
            return state if isinstance(state, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_state(base_dir, state):
    file_descriptor, temporary_path = tempfile.mkstemp(prefix=".swill-state-", dir=base_dir)
    try:
        with os.fdopen(file_descriptor, "w", encoding="utf-8") as state_file:
            json.dump(state, state_file)
        os.replace(temporary_path, _state_path(base_dir))
    finally:
        if os.path.exists(temporary_path):
            os.remove(temporary_path)


def _check_for_update(base_dir):
    state = _read_state(base_dir)
    remote_version = _remote_version()
    if not remote_version or remote_version == state.get("remote_version"):
        return False

    package = _download_package()
    package_hash = hashlib.sha256(package).hexdigest()
    if package_hash == state.get("package_hash"):
        state["remote_version"] = remote_version
        _write_state(base_dir, state)
        return False

    changed = _install_package(package, base_dir)
    _write_state(
        base_dir,
        {
            "remote_version": remote_version,
            "package_hash": package_hash,
            "restart_pid": os.getpid() if changed else None,
        },
    )
    if changed:
        LOGGER.info("Найдено обновление SWILL; перезапускаю приложение")
    return changed


def _restart(base_dir):
    app_path = os.path.join(base_dir, "app.py")
    if not os.path.isfile(app_path):
        raise FileNotFoundError("Не найден app.py для перезапуска")
    os.execv(sys.executable, [sys.executable, app_path])


def _monitor(base_dir):
    time.sleep(30)
    while True:
        try:
            state = _read_state(base_dir)
            restart_pid = state.get("restart_pid")
            if restart_pid and restart_pid != os.getpid():
                state["restart_pid"] = None
                _write_state(base_dir, state)
            elif restart_pid == os.getpid():
                _restart(base_dir)

            if _check_for_update(base_dir):
                _restart(base_dir)
        except Exception:
            LOGGER.exception("Не удалось проверить обновление SWILL")
        time.sleep(CHECK_INTERVAL_SECONDS)


def start_updater(base_dir):
    thread = threading.Thread(
        target=_monitor,
        args=(base_dir,),
        name="swill-updater",
        daemon=True,
    )
    thread.start()