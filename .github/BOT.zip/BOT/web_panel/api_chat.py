from datetime import datetime
from flask import jsonify, request
from flask_login import current_user
import config
import storage

def api_chat_get():
    return jsonify(storage.load_json(config.CHAT_FILE))

def api_chat_send():
    d = request.json
    msg = d.get('message', '').strip()
    if not msg:
        return jsonify({'error': 'Empty'})
    chat = storage.load_json(config.CHAT_FILE)
    chat.append({
        "username": current_user.id,
        "message": msg,
        "time": datetime.now().strftime('%H:%M:%S')
    })
    if len(chat) > 100:
        chat = chat[-100:]
    storage.save_json(config.CHAT_FILE, chat)
    return jsonify({'ok': True})