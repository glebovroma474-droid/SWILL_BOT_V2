import time
from datetime import datetime
from flask import render_template, request, redirect, url_for
from flask_login import UserMixin, login_user, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import config
import storage

class User(UserMixin):
    def __init__(self, u):
        self.id = u
    
    @property
    def role(self):
        return storage.load_json(config.USERS_FILE).get(self.id, {}).get('role', 'user')

def load_user(u):
    if u in storage.load_json(config.USERS_FILE):
        return User(u)
    return None

def login():
    error = None
    if request.method == 'POST':
        u = request.form.get('username', '').strip()
        p = request.form.get('password', '')
        blocked = storage.load_json(config.BLOCKED_FILE)
        
        if blocked.get(u, {}).get('attempts', 0) >= config.MAX_LOGIN_ATTEMPTS:
            error = 'Аккаунт заблокирован'
        else:
            users = storage.load_json(config.USERS_FILE)
            if u in users and check_password_hash(users[u]['password'], p):
                login_user(User(u))
                users[u]['last_login'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                users[u]['last_active'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                storage.save_json(config.USERS_FILE, users)
                if u in blocked:
                    blocked[u]['attempts'] = 0
                storage.save_json(config.BLOCKED_FILE, blocked)
                return redirect(url_for('index'))
            else:
                if u not in blocked:
                    blocked[u] = {'attempts': 0}
                blocked[u]['attempts'] += 1
                storage.save_json(config.BLOCKED_FILE, blocked)
                error = 'Неверный логин или пароль'
    
    return render_template('login.html', error=error)

def register():
    error = None
    if request.method == 'POST':
        u = request.form.get('username', '').strip()
        p = request.form.get('password', '').strip()
        if not u or not p:
            error = 'Заполните все поля'
        elif len(p) < 4:
            error = 'Пароль минимум 4 символа'
        else:
            users = storage.load_json(config.USERS_FILE)
            if u in users:
                error = 'Пользователь существует'
            else:
                users[u] = {
                    'password': generate_password_hash(p),
                    'role': 'user',
                    'color': '#4ade80',
                    'created': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'last_login': '',
                    'last_active': '',
                    'xp': 0
                }
                storage.save_json(config.USERS_FILE, users)
                return redirect(url_for('login'))
    return render_template('register.html', error=error)

def logout():
    logout_user()
    return redirect(url_for('login_route'))

def add_xp(u, amt):
    users = storage.load_json(config.USERS_FILE)
    if u in users:
        users[u]['xp'] = users[u].get('xp', 0) + amt
        users[u]['last_active'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        storage.save_json(config.USERS_FILE, users)

def log_action(u, act, det="", status="ok"):
    log = storage.load_json(config.LOG_FILE)
    names = {
        'LOGIN': 'Вход в систему',
        'LOGOUT': 'Выход из системы',
        'REGISTER': 'Регистрация',
        'reboot': 'Перезагрузка',
        'shutdown': 'Выключение',
        'shutdown_abort': 'Отмена выключения',
        'sleep': 'Спящий режим',
        'hibernate': 'Гибернация',
        'lock': 'Блокировка экрана',
        'screen_off': 'Экран выключен',
        'block_input': 'Блокировка ввода',
        'unblock_input': 'Разблокировка ввода',
        'vol': 'Изменение громкости',
        'bright': 'Изменение яркости',
        'media_play': 'Play/Pause',
        'media_next': 'Next',
        'media_prev': 'Prev',
        'media_stop': 'Stop',
        'roblox': 'Roblox',
        'trolleybus': 'Троллейбус',
        'wot': 'Мир Танков',
        'wotb': 'Tanks Blitz',
        'clean': 'Очистка системы',
        'speedtest': 'Спидтест',
        'windows_info': 'Информация о системе',
    }
    log[str(time.time())] = {
        "username": u,
        "action": act,
        "action_name": names.get(act, act),
        "details": det,
        "status": status,
        "time": datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "timestamp": time.time()
    }
    cutoff = time.time() - 90 * 86400
    storage.save_json(config.LOG_FILE, {k: v for k, v in log.items() if float(k) >= cutoff})