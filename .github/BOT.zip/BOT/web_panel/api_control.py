import os
import socket
import ctypes
from flask import jsonify
from flask_login import current_user
from services_audio import audio
from services_input import input_blocker

def api_do(action):
    role = current_user.role
    if role == 'guest':
        return jsonify({'ok': False, 'msg': 'Нет прав'})
    if role == 'user' and action in ['reboot', 'shutdown', 'block_input', 'unblock_input']:
        return jsonify({'ok': False, 'msg': 'Только для админа'})
    
    try:
        if action == 'lock':
            ctypes.windll.user32.LockWorkStation()
        elif action == 'sleep':
            os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
        elif action == 'hibernate':
            os.system('shutdown /h')
        elif action == 'shutdown_abort':
            os.system('shutdown /a')
        elif action == 'screen_off':
            ctypes.windll.user32.SendMessageW(0xFFFF, 0x0112, 0xF170, 2)
        elif action == 'reboot':
            os.system("shutdown /r /t 3")
        elif action == 'shutdown':
            os.system("shutdown /s /t 3")
        elif action == 'minimize':
            ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x4D, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x4D, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)
        elif action == 'restore':
            ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x10, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x4D, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x4D, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x10, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)
        elif action == 'alt_f4':
            ctypes.windll.user32.keybd_event(0x12, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x73, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x73, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x12, 0, 2, 0)
        elif action == 'f5':
            ctypes.windll.user32.keybd_event(0x74, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x74, 0, 2, 0)
        elif action == 'alt_tab':
            ctypes.windll.user32.keybd_event(0x12, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x09, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x09, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x12, 0, 2, 0)
        elif action == 'show_desktop':
            ctypes.windll.user32.keybd_event(0x5B, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x44, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x44, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x5B, 0, 2, 0)
        elif action == 'vol_up':
            ctypes.windll.user32.keybd_event(0xAF, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0xAF, 0, 2, 0)
        elif action == 'vol_down':
            ctypes.windll.user32.keybd_event(0xAE, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0xAE, 0, 2, 0)
        elif action == 'vol_mute':
            ctypes.windll.user32.keybd_event(0xAD, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0xAD, 0, 2, 0)
        elif action == 'media_play' or action == 'media_pause':
            ctypes.windll.user32.keybd_event(0xB3, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0xB3, 0, 2, 0)
        elif action == 'media_next':
            ctypes.windll.user32.keybd_event(0xB0, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0xB0, 0, 2, 0)
        elif action == 'media_prev':
            ctypes.windll.user32.keybd_event(0xB1, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0xB1, 0, 2, 0)
        elif action == 'media_stop':
            ctypes.windll.user32.keybd_event(0xB2, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0xB2, 0, 2, 0)
        elif action == 'yt_up':
            ctypes.windll.user32.keybd_event(0x26, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x26, 0, 2, 0)
        elif action == 'yt_down':
            ctypes.windll.user32.keybd_event(0x28, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x28, 0, 2, 0)
        elif action == 'yt_pause':
            ctypes.windll.user32.keybd_event(0x20, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x20, 0, 2, 0)
        elif action == 'roblox':
            os.system("start roblox://")
        elif action == 'trolleybus':
            os.system('start "" "roblox://placeId=2337102976"')
        elif action == 'wot':
            os.system('start "" "C:\\Games\\Tanki\\Tanki.exe"')
        elif action == 'wotb':
            os.system('start "" "C:\\Games\\Tanks_Blitz\\tanksblitz.exe"')
        elif action == 'switch_layout':
            ctypes.windll.user32.keybd_event(0x12, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x10, 0, 0, 0)
            ctypes.windll.user32.keybd_event(0x10, 0, 2, 0)
            ctypes.windll.user32.keybd_event(0x12, 0, 2, 0)
        elif action == 'clean':
            import tempfile
            freed = 0
            try:
                tp = tempfile.gettempdir()
                for f in os.listdir(tp):
                    try:
                        fp = os.path.join(tp, f)
                        if os.path.isfile(fp):
                            os.remove(fp)
                            freed += 1
                    except:
                        pass
            except:
                pass
            return jsonify({'ok': True, 'msg': f'Очищено {freed} файлов'})
        elif action == 'speedtest':
            try:
                import speedtest
                st = speedtest.Speedtest()
                st.get_best_server()
                dl = st.download() / 1_000_000
                ul = st.upload() / 1_000_000
                msg = f'DL: {dl:.1f} Mbps | UL: {ul:.1f} Mbps | Ping: {st.results.ping:.0f} ms'
                return jsonify({'ok': True, 'msg': msg})
            except:
                return jsonify({'ok': False, 'msg': 'Ошибка спидтеста'})
        elif action == 'windows_info':
            import platform as pf
            msg = f"{pf.win32_ver()[0]} {pf.win32_ver()[1]}\n{socket.gethostname()}\n{os.getlogin()}"
            return jsonify({'ok': True, 'msg': msg})
        elif action.startswith('vol_'):
            val = int(action.replace('vol_', ''))
            if audio.set(val):
                return jsonify({'ok': True})
            return jsonify({'ok': False, 'msg': 'Ошибка звука'})
        elif action.startswith('bright_'):
            try:
                import screen_brightness_control as sbc
                val = int(action.replace('bright_', ''))
                sbc.set_brightness(val)
                return jsonify({'ok': True})
            except:
                return jsonify({'ok': False, 'msg': 'Ошибка яркости'})
        elif action == 'block_input':
            if not input_blocker.is_locked:
                input_blocker.toggle()
                return jsonify({'ok': True, 'msg': 'Заблокировано'})
            return jsonify({'ok': True, 'msg': 'Уже заблокировано'})
        elif action == 'unblock_input':
            if input_blocker.is_locked:
                input_blocker.toggle()
                return jsonify({'ok': True, 'msg': 'Разблокировано'})
            return jsonify({'ok': True, 'msg': 'Уже разблокировано'})
        else:
            return jsonify({'ok': False, 'msg': 'Неизвестно'})
        
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})