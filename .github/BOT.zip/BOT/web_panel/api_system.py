import time
import os as _os
import socket
import subprocess
import ctypes
import re
import threading
from datetime import datetime, timedelta
import psutil
import pyautogui
from flask import jsonify
from flask_login import current_user
import config
import storage
from services_audio import audio
from services_input import input_blocker

_network_lock = threading.Lock()
_last_network_sample = None
_ping_lock = threading.Lock()
_ping_value = 'N/A'
_ping_checked_at = 0
_ping_in_flight = False

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return 'N/A'

def get_brightness():
    try:
        import warnings
        warnings.filterwarnings("ignore")
        import screen_brightness_control as sbc
        b = sbc.get_brightness()
        if isinstance(b, list):
            return b[0]
        return b
    except:
        return 50

def get_network_rates():
    global _last_network_sample
    current = psutil.net_io_counters()
    now = time.monotonic()
    with _network_lock:
        previous = _last_network_sample
        _last_network_sample = (now, current.bytes_recv, current.bytes_sent)

    if previous is None:
        return '0 KB/s', '0 KB/s'

    elapsed = now - previous[0]
    if elapsed <= 0:
        return '0 KB/s', '0 KB/s'

    download_rate = max(0, current.bytes_recv - previous[1]) / elapsed / 1024
    upload_rate = max(0, current.bytes_sent - previous[2]) / elapsed / 1024
    download = f'{download_rate / 1024:.1f} MB/s' if download_rate >= 1024 else f'{download_rate:.0f} KB/s'
    upload = f'{upload_rate / 1024:.1f} MB/s' if upload_rate >= 1024 else f'{upload_rate:.0f} KB/s'
    return download, upload

def _refresh_ping():
    global _ping_value, _ping_checked_at, _ping_in_flight
    try:
        result = subprocess.run(
            ['ping', '-n', '1', 'google.com'],
            capture_output=True,
            text=True,
            timeout=2,
        )
        match = re.search(r'time[=<]\s*([\d.]+)\s*ms', result.stdout)
        value = f'{match.group(1)} ms' if match else 'N/A'
    except Exception:
        value = 'N/A'
    finally:
        with _ping_lock:
            _ping_value = value
            _ping_checked_at = time.monotonic()
            _ping_in_flight = False

def get_cached_ping():
    global _ping_in_flight
    should_refresh = False
    with _ping_lock:
        if not _ping_in_flight and time.monotonic() - _ping_checked_at >= 30:
            _ping_in_flight = True
            should_refresh = True
        value = _ping_value

    if should_refresh:
        threading.Thread(target=_refresh_ping, daemon=True, name='swill-ping').start()
    return value

def get_sys_info():
    cpu = psutil.cpu_percent(interval=0)
    ram = psutil.virtual_memory()
    disk = psutil.disk_usage('C:')
    
    cpu_temp = "N/A"
    try:
        temps = psutil.sensors_temperatures()
        if 'coretemp' in temps:
            cpu_temp = f"{temps['coretemp'][0].current}°C"
    except:
        pass
    
    battery = 'N/A'
    try:
        b = psutil.sensors_battery()
        if b:
            battery = f"{int(b.percent)}% {'AC' if b.power_plugged else 'BAT'}"
    except:
        pass
    
    try:
        dl, ul = get_network_rates()
    except:
        dl = ul = "N/A"
    
    try:
        sec = ctypes.windll.kernel32.GetTickCount64() / 1000
        uptime = str(timedelta(seconds=int(sec)))
    except:
        uptime = "N/A"
    
    try:
        import win32gui
        hwnd = win32gui.GetForegroundWindow()
        active = win32gui.GetWindowText(hwnd) or "Desktop"
    except:
        active = "Unknown"
    
    ping = get_cached_ping()
    
    return {
        'cpu': cpu,
        'ram_percent': ram.percent,
        'ram_used': f"{ram.used/(1024**3):.1f}",
        'ram_total': f"{ram.total/(1024**3):.1f}",
        'disk_percent': disk.percent,
        'temp': cpu_temp,
        'battery': battery,
        'uptime': uptime,
        'hostname': socket.gethostname(),
        'local_ip': get_local_ip(),
        'active_window': active,
        'locked': input_blocker.is_locked,
        'volume': audio.get(),
        'brightness': get_brightness(),
        'network': {'download': dl, 'upload': ul},
        'ping': ping,
        'time': datetime.now().strftime('%H:%M:%S')
    }

def api_status():
    return jsonify(get_sys_info())

def api_screenshot():
    try:
        shot = pyautogui.screenshot()
        filename = f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        filepath = _os.path.join(config.BASE_DIR, 'screenshots', filename)
        _os.makedirs(_os.path.dirname(filepath), exist_ok=True)
        shot.save(filepath, format='JPEG', quality=70)
        return jsonify({'ok': True, 'msg': 'Сохранено'})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)})