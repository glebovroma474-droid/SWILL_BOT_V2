from threading import Lock

class AudioController:
    def __init__(self):
        self._lock = Lock()
        self._iface = None
        self._ok = False
        try:
            from pycaw.pycaw import AudioUtilities
            self._iface = AudioUtilities.GetSpeakers().EndpointVolume
            self._ok = True
        except:
            pass
    
    def get(self):
        if not self._ok:
            return -1
        try:
            with self._lock:
                return int(self._iface.GetMasterVolumeLevelScalar() * 100)
        except:
            return -1
    
    def set(self, p):
        if not self._ok:
            return False
        try:
            p = max(0, min(100, p))
            with self._lock:
                self._iface.SetMasterVolumeLevelScalar(p / 100.0, None)
            return True
        except:
            return False

audio = AudioController()